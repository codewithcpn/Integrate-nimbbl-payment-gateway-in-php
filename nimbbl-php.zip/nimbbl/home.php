<?php

// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

include 'Nimbbl.php';
use Nimbbl\Api\NimbblApi;
use Nimbbl\Api\NimbblOrder;
$api = new NimbblApi('access_key_ArL0OVxeqOlD13zP', 'access_secret_j5N7AKal6WKP23qY');

  if(isset($_POST['submit']))
  {
      
      $name      = $_POST['name'];
      $lname      = $_POST['lname'];
      $email   = $_POST['email'];
      $mobile   = $_POST['mobile'];
      $quantity   = $_POST['quantity'];
      $gstAmount   = $_POST['gstAmount'];
      $amount   = $_POST['amount'];
      $invoiceId   = $_POST['invoiceId'];
      
     
      $totalAmount = $amount + $gstAmount;
      
  

    $order_data = array(
            'referrer_platform' => 'referrer_platform',
            'merchant_shopfront_domain' => 'http://dekhoaurkharido.in/',
            'invoice_id' => $invoiceId,
            'order_date' => date('Y-m-d H:i:s'),
            'currency' => 'INR',
            'amount_before_tax' => $amount,
            'tax' => $gstAmount,
            'total_amount' =>  $totalAmount,
            "user" => [
                "mobile_number" =>  $mobile,
                "email" =>  $email,
                "first_name" =>  $name,
                "last_name" => $lname,
            ],
            'shipping_address' => [
                'area' => '',
                'city' => '',
                'state' => '',
                'pincode' => '',
                'address_type' => ''
            ],
            "order_line_items" => [
                [
                    "title" => "",
                    "quantity" =>  $quantity,
                    'uom' => '',
                    'image_url' => 'image_url',
                    'description' => '',
                    'sku_id' => 'P1',
                    'amount_before_tax' => $amount,
                    'tax' =>  $gstAmount,
                    "total_amount" =>  $totalAmount,
                ]
            ],
            'description' => '',
        );
    $newOrder = $api->order->create($order_data);
 
   
    
    
  }
     ?>
     
     <script src="https://api.nimbbl.tech/static/assets/js/checkout.js"></script>
<script>
 let order_id = '<?php echo  $newOrder->order_id?>';
 var options = {
                "access_key": "access_key_ArL0OVxeqOlD13zP", // Enter the Key ID generated from the Dashboard
                "order_id": order_id, // Enter the order_id from the create-order api
                "callback_url": "https://dekhoaurkharido.in/nimbbl/response.php", // Enter the call back url
                "redirect":true,
                "custom": {
                    "key_1": "12345",
                    "key_2": "54321"
                },
            };

var checkout = new NimbblCheckout(options);
checkout.open(order_id);
</script>

     
   

     
   