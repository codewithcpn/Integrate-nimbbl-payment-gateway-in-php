<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Page</title>
  <!-- Add Bootstrap CSS link -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    .image-container {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-5 image-container bg-primary text-white">
      <h1>Welcome!</h1>
      <p>100% Secure Payment</p>
    </div>
    <?php
    
    $invoiceId = rand().'NIMBBL';
    
    ?>
    <div class="col-md-5  offset-md-1">
       <img src="https://dekhoaurkharido.in/assets/img/logo-dekho-logo-removebg-preview.png">
   <form action="home.php" method="POST">
       
    <div class="mb-3 mt-3">
      <!--<label for="email">Name:</label>-->
      <input type="text" class="form-control"  placeholder="Enter first name - required" name="name" >
    </div>
    
    <div class="mb-3 mt-3">
      <!--<label for="email">Name:</label>-->
      <input type="text" class="form-control"  placeholder="Enter last name - required" name="lname" >
    </div>
    
     <div class="mb-3 mt-3 col">
      <!--<label for="email">Email:</label>-->
      <input type="email" class="form-control" placeholder="Enter email id - required" name="email" required>
    </div>
    
    <div class="mb-3">
      <!--<label for="pwd">Mobile no:</label>-->
      <input type="text" class="form-control"  placeholder="Enter mobile no - required" name="mobile" required>
    </div>
    
     <div class="mb-3">
      <!--<label for="pwd">State:</label>-->
      <input type="number" class="form-control" id="pwd" placeholder="Enter product quantity - required" name="quantity" >
    </div>
    
     <div class="mb-3">
      <!--<label for="pwd">Pin Code:</label>-->
      <input type="text" class="form-control" id="pwd" placeholder="Enter product amount - required" name="amount" required>
    </div>
    
     <div class="mb-3 mt-3">
      
      <input type="hidden" class="form-control"  name="invoiceId" value="<?php echo $invoiceId;?>">
      <input type="text" class="form-control"  placeholder="Enter GST amount - required" name="gstAmount" required>
    </div>
    
    <button type="submit"  name="submit" class="btn btn-primary">Pay now</button>
  </form>
    </div>
  </div>
</div>

<!-- Add Bootstrap JS link -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
