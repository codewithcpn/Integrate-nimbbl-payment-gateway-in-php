<?php

// Get the base64 encoded response from the callback URL
$base64Response = $_GET['response'] ?? ''; // Assuming you're using POST method to receive the response

// Decode the base64 response
$decodedResponse = base64_decode($base64Response);

// Convert the decoded response to a JSON object
$responseData = json_decode($decodedResponse);



$message                = $responseData->payload->message;
$nimbbl_order_id        = $responseData->payload->nimbbl_order_id;
$nimbbl_transaction_id    = $responseData->payload->nimbbl_transaction_id;
$nimbbl_signature   = $responseData->nimbbl_signature;
$invoice_id   = $responseData->payload->order->invoice_id;
$status   = $responseData->payload->status;

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment response</title>
  <!-- Add Bootstrap CSS link -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    .image-container {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-6 image-container bg-primary text-white">
      <h1>Welcome!</h1>
      <p>100% Secure Payment</p>
    </div>
    <?php
    
    $order_id = rand().'tgsf';
    
    ?>
    <div class="col-md-6 py-5">
       <img src="https://dekhoaurkharido.in/assets/img/logo-dekho-logo-removebg-preview.png" class="pl-5">
         <table class="table table-striped py-5 px-3 mt-5">
        
        <tbody>
          <tr>
            <td><strong>Invoice Id </strong></td>
            <td><?php echo $invoice_id; ?></td>
          </tr>
          
            <tr>
             <td><strong>Transaction Id </strong></td>
            <td><?php echo $nimbbl_transaction_id; ?></td>
          </tr>
          
            <tr>
             <td><strong>Payment Message </strong></td>
            <td><?php echo $message; ?></td>
          </tr>
          
           <tr>
             <td><strong>Status </strong></td>
            <td><?php echo $status; ?></td>
          </tr>
         
        </tbody>
      </table>
      
      <a href="https://dekhoaurkharido.in/" class="btn btn-lg btn-primary mt-5"> Back to Website</a>
    </div>
  </div>
</div>

<!-- Add Bootstrap JS link -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

